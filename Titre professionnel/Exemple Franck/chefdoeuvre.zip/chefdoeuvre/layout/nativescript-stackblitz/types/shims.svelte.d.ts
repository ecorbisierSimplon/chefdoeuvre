declare module '*.svelte' {
    export { SvelteComponent as default };
}
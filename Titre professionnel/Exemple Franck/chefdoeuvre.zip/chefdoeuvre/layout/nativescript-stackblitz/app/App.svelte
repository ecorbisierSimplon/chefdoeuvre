<frame>
    <Home />
</frame>

<script lang="ts">
    import Home from './components/Home.svelte'
</script>
<page>
    <actionBar title="Home" />
    <gridLayout>
        <label class="text-xl align-middle text-center text-gray-500" text="{message}" />
    </gridLayout>
</page>

<script lang="ts">
    let message: string = "Blank Svelte Native App"
</script>

<style>
    /* .info {
        font-size: 20;
    } */
</style>

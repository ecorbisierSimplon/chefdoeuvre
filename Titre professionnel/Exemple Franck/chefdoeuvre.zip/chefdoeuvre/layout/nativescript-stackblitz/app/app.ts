import { svelteNativeNoFrame } from 'svelte-native';
import App from './App.svelte';

svelteNativeNoFrame(App, {});

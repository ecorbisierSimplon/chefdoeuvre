code --install-extension 1yib.svelte-bundle

<!-- code --install-extension aessoft.aessoft-class-autocomplete -->

code --install-extension alexcvzz.vscode-sqlite
code --install-extension anilkumarum.compile-ts
code --install-extension ardenivanov.svelte-intellisense
code --install-extension bierner.markdown-checkbox

<!-- code --install-extension bierner.markdown-emoji -->

code --install-extension bierner.markdown-footnotes

<!-- code --install-extension bierner.markdown-mermaid -->

code --install-extension bierner.markdown-preview-github-styles
code --install-extension bierner.markdown-yaml-preamble
code --install-extension bmewburn.vscode-intelephense-client
code --install-extension brysonbw.svelte-component-snippets
code --install-extension christian-kohler.npm-intellisense
code --install-extension compulim.compulim-vscode-closetag

<!-- code --install-extension csholmq.excel-to-markdown-table -->

code --install-extension cucumberopen.cucumber-official
code --install-extension cweijan.vscode-office

<!-- code --install-extension davidanson.vscode-markdownlint -->

code --install-extension dbaeumer.vscode-eslint
code --install-extension derappelt.symfony-console
code --install-extension dervex.universal-comments
code --install-extension devsense.composer-php-vscode
code --install-extension devsense.phptools-vscode
code --install-extension devsense.profiler-php-vscode

<!-- code --install-extension docsmsft.docs-markdown -->

code --install-extension eiminsasete.apacheconf-snippets

<!-- code --install-extension esbenp.prettier-vscode -->

code --install-extension fabiospampinato.vscode-highlight
code --install-extension fivethree.vscode-svelte-snippets

<!-- code --install-extension formulahendry.auto-close-tag -->
<!-- code --install-extension formulahendry.auto-rename-tag -->

code --install-extension github.github-vscode-theme
code --install-extension github.vscode-github-actions
code --install-extension github.vscode-pull-request-github
code --install-extension glenn2223.live-sass
code --install-extension hackmd.vscode-hackmd
code --install-extension henrikvilhelmberglund.vscode-svelte-snippets-henrikvilhelmberglund
code --install-extension huntertran.auto-markdown-toc
code --install-extension j4ng5y.charactercount
code --install-extension jakobkruse.svelte-kit-snippets

<!-- code --install-extension jebbs.markdown-extended -->

code --install-extension jock.svg
code --install-extension joffreykern.markdown-toc
code --install-extension marp-team.marp-vscode
code --install-extension mechatroner.rainbow-csv
code --install-extension mehedidracula.php-namespace-resolver
code --install-extension mervin.markdown-formatter
code --install-extension mhutchie.git-graph
code --install-extension mintlify.document

<!-- code --install-extension svsool.markdown-memo -->

<!-- code --install-extension ms-azuretools.vscode-docker -->
<!-- code --install-extension ms-ceintl.vscode-language-pack-fr -->

code --install-extension ms-playwright.playwright

<!-- code --install-extension ms-vscode-remote.remote-containers -->

code --install-extension ms-vscode-remote.remote-wsl

<!-- code --install-extension ms-vscode.notepadplusplus-keybindings -->

code --install-extension ms-vsliveshare.vsliveshare
code --install-extension mskelton.playwright-test-snippets
code --install-extension muath-ye.svelte-expack
code --install-extension nadim-vscode.infinity-dark-theme
code --install-extension nadim-vscode.symfony-code-snippets
code --install-extension nadim-vscode.twig-code-snippets
code --install-extension nativescript.nativescript
code --install-extension natizyskunk.sftp

<!-- code --install-extension naumovs.color-highlight -->

code --install-extension noahbeij.marp-codecafe-snippets
code --install-extension ntb.theme-symfony-dark
code --install-extension pivaszbs.svelte-autoimport
code --install-extension pmneo.tsimporter
code --install-extension rafaelmartinez.svelte-preview
code --install-extension redhat.fabric8-analytics
code --install-extension redhat.java
code --install-extension rifi2k.format-html-in-php
code --install-extension ritwickdey.liveserver
code --install-extension robole.markdown-snippets

<!-- code --install-extension shd101wyy.markdown-preview-enhanced -->

code --install-extension sidthesloth.html5-boilerplate

<!-- code --install-extension simonsiefke.svg-preview -->

code --install-extension sohibe.java-generate-setters-getters
code --install-extension svelte.svelte-vscode
code --install-extension telesoho.vscode-markdown-paste-image
code --install-extension thenouillet.symfony-vscode
code --install-extension tomoki1207.pdf
code --install-extension tsutsu3.markdown-named-codeblocks
code --install-extension tsvetan-ganev.nativescript-xml-snippets
code --install-extension visualstudioexptteam.intellicode-api-usage-examples
code --install-extension visualstudioexptteam.vscodeintellicode
code --install-extension vmware.vscode-boot-dev-pack
code --install-extension vmware.vscode-spring-boot
code --install-extension vscjava.vscode-gradle
code --install-extension vscjava.vscode-java-debug
code --install-extension vscjava.vscode-java-dependency
code --install-extension vscjava.vscode-java-pack
code --install-extension vscjava.vscode-java-test
code --install-extension vscjava.vscode-maven
code --install-extension vscjava.vscode-spring-boot-dashboard
code --install-extension vscjava.vscode-spring-initializr
code --install-extension wallabyjs.console-ninja
code --install-extension wibblemonkey.markdown-auto-toc
code --install-extension wscats.eno
code --install-extension xdebug.php-debug
code --install-extension xdebug.php-pack
code --install-extension yangtangwu.html-to-markdown
code --install-extension yoavbls.pretty-ts-errors
code --install-extension youmaycallmev.vscode-java-saber
code --install-extension yzane.markdown-pdf

<!-- code --install-extension yzhang.markdown-all-in-one -->

code --install-extension zignd.html-css-class-completion
code --install-extension zobo.php-intellisense

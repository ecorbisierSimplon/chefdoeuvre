## Chartre graphique

- **Palette de Bleues Apaisants :**

| Nom        | code couleur                                                                |
| ---------- | --------------------------------------------------------------------------- |
| Bleu Clair | <span style="background-color: #6FA3EF; padding: 5px 10px;" >#6FA3EF</span> |
| Bleu Pâle  | <span style="background-color: #BDD7FD; padding: 5px 10px;" >#BDD7FD</span> |
| Bleu Ciel  | <span style="background-color: #A2C8E6; padding: 5px 10px;" >#A2C8E6</span> |

---

- **Palette de Bleues Apaisants :**

| Nom        | code couleur                                                                |
| ---------- | --------------------------------------------------------------------------- |
| Bleu Clair | <span style="background-color: #507599; padding: 5px 10px;" >#507599</span> |
| Bleu Pâle  | <span style="background-color: #ABB6C8; padding: 5px 10px;" >#ABB6C8</span> |
| Gris       | <span style="background-color: #DADADA; padding: 5px 10px;" >#DADADA</span> |
| Jaune      | <span style="background-color: #F7F0C6; padding: 5px 10px;" >#F7F0C6</span> |
| Gris vert  | <span style="background-color: #C2C4B6; padding: 5px 10px;" >#C2C4B6</span> |

---

- **Palette de Verts Naturels :**

| Nom             | code couleur                                                                |
| --------------- | --------------------------------------------------------------------------- |
| Vert d'Eau      | <span style="background-color: #7FD0A6; padding: 5px 10px;" >#7FD0A6</span> |
| Vert Tendre     | <span style="background-color: #A4E3B9; padding: 5px 10px;" >#A4E3B9</span> |
| Vert Olive Doux | <span style="background-color: #C2D69C; padding: 5px 10px;" >#C2D69C</span> |

---

- **Palette Neutre Douce :**

| Nom         | code couleur                                                                |
| ----------- | --------------------------------------------------------------------------- |
| Gris Clair  | <span style="background-color: #DADADA; padding: 5px 10px;" >#DADADA</span> |
| Beige Doux  | <span style="background-color: #EAE5D5; padding: 5px 10px;" >#EAE5D5</span> |
| Blanc Cassé | <span style="background-color: #F7F4EB; padding: 5px 10px;" >#F7F4EB</span> |

---

- **Palette de Roses Apaisants :**

| Nom         | code couleur                                                                |
| ----------- | --------------------------------------------------------------------------- |
| Rose Poudré | <span style="background-color: #F4BCC4; padding: 5px 10px;" >#F4BCC4</span> |
| Rose Pastel | <span style="background-color: #F8D7DC; padding: 5px 10px;" >#F8D7DC</span> |
| Rose Doux   | <span style="background-color: #FCE2E4; padding: 5px 10px;" >#FCE2E4</span> |

---

- **Palette de Violets Relaxants :**

| Nom            | code couleur                                                                |
| -------------- | --------------------------------------------------------------------------- |
| Violet Lavande | <span style="background-color: #BFA9DB; padding: 5px 10px;" >#BFA9DB</span> |
| Violet Pastel  | <span style="background-color: #D8C8E9; padding: 5px 10px;" >#D8C8E9</span> |
| Violet Doux    | <span style="background-color: #E8DCF7; padding: 5px 10px;" >#E8DCF7</span> |

---
marp: true
theme: cda_eric_two
paginate: false
_paginate: false # or use `_paginate: skip`

transition: swoosh
footer: ""
---

<!-- _class: one -->

# Tranquillo Organizer App

---

![imag left:30% 80%](https://cda.corbisier.fr/layout/img/logo.webp)

ssh u71988742@home451601943.1and1-data.host

mariadb -p dbs11539030 -h db5013786871.hosting-data.io -u dbu1816983
